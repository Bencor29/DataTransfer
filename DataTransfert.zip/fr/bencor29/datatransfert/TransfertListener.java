package fr.bencor29.datatransfert;

public abstract class TransfertListener {
	
	public abstract void receive(ReceivedString received);

}
