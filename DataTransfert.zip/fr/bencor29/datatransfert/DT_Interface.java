package fr.bencor29.datatransfert;

import javax.swing.JOptionPane;

public class DT_Interface {
	
	public static void main(String[] args) {
		JOptionPane.showMessageDialog(null, "This is not a real program but an API!", "Error", JOptionPane.ERROR_MESSAGE);
		System.exit(0);
	}

}
