package fr.bencor29.datatransfert;

@SuppressWarnings("serial")
public class ReservedException extends Exception {
	
	protected ReservedException(String str) {
		super(str);
	}
	
}
